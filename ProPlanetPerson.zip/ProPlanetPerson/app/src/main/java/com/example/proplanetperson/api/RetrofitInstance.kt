package com.example.proplanetperson.api

import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

object RetrofitInstance {
    val api: QuoteApi by lazy {
        val loggingInterceptor = HttpLoggingInterceptor()
        loggingInterceptor.level = HttpLoggingInterceptor.Level.BODY // Logs request/response bodies

        val okHttpClient = OkHttpClient.Builder()
            .addInterceptor(loggingInterceptor)
            .build()

        Retrofit.Builder()
            .baseUrl("https://type.fit/api/") // Base URL
            .addConverterFactory(GsonConverterFactory.create()) // For converting JSON to Kotlin objects
            .client(okHttpClient) // Adding the logging interceptor
            .build()
            .create(QuoteApi::class.java)
    }
}
