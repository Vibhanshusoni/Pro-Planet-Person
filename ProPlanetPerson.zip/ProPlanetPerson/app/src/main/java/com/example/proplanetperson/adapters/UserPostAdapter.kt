package com.example.proplanetperson.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.proplanetperson.R
import com.example.proplanetperson.models.Post

class UserPostAdapter(private val postList: List<Post>) :
    RecyclerView.Adapter<UserPostAdapter.PostViewHolder>() {

    inner class PostViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val mediaImage: ImageView = view.findViewById(R.id.media_image)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PostViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_user_post, parent, false)
        return PostViewHolder(view)
    }

    override fun onBindViewHolder(holder: PostViewHolder, position: Int) {
        val post = postList[position]

        // Load image or video thumbnail using Glide
        Glide.with(holder.itemView.context)
            .load(post.url)
            .placeholder(R.drawable.ic_profile_placeholder)
            .into(holder.mediaImage)

        // Optional: add click listener to view post in detail
        holder.itemView.setOnClickListener {
            // Future: open full screen post preview
        }
    }

    override fun getItemCount(): Int = postList.size
}
