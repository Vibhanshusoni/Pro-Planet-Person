package com.example.proplanetperson.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ProgressBar
import androidx.appcompat.widget.SearchView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.proplanetperson.R
import com.example.proplanetperson.adapters.SearchAdapter
import com.example.proplanetperson.models.SearchItem
import com.google.firebase.database.*

class SearchFragment : Fragment() {

    private lateinit var searchView: SearchView
    private lateinit var recyclerView: RecyclerView
    private lateinit var progressBar: ProgressBar
    private lateinit var searchAdapter: SearchAdapter
    private val searchResults = mutableListOf<SearchItem>()
    private lateinit var database: DatabaseReference

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val view = inflater.inflate(R.layout.fragment_search, container, false)

        searchView = view.findViewById(R.id.search_view)
        recyclerView = view.findViewById(R.id.recycler_search_results)
        progressBar = view.findViewById(R.id.loading_progress)

        recyclerView.layoutManager = LinearLayoutManager(context)
        searchAdapter = SearchAdapter(searchResults)
        recyclerView.adapter = searchAdapter

        database = FirebaseDatabase.getInstance().reference

        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                query?.let { performSearch(it.trim().lowercase()) }
                return true
            }

            override fun onQueryTextChange(newText: String?): Boolean {
                newText?.let { performSearch(it.trim().lowercase()) }
                return true
            }
        })

        return view
    }

    private fun performSearch(query: String) {
        progressBar.visibility = View.VISIBLE
        searchResults.clear()
        searchAdapter.notifyDataSetChanged()

        // Users
        database.child("users").orderByChild("username")
            .startAt(query).endAt(query + "\uf8ff")
            .addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    snapshot.children.forEach { snap ->
                        val username = snap.child("username").getValue(String::class.java)
                        val id = snap.key ?: ""
                        if (!username.isNullOrEmpty()) {
                            searchResults.add(SearchItem("User", username, id))
                        }
                    }
                    searchAdapter.notifyDataSetChanged()
                    progressBar.visibility = View.GONE
                }

                override fun onCancelled(error: DatabaseError) {
                    showError(error.message)
                }
            })

        // Titles
        database.child("posts").orderByChild("title")
            .startAt(query).endAt(query + "\uf8ff")
            .addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    snapshot.children.forEach { snap ->
                        val title = snap.child("title").getValue(String::class.java)
                        val id = snap.key ?: ""
                        if (!title.isNullOrEmpty()) {
                            searchResults.add(SearchItem("Title", title, id))
                        }
                    }
                    searchAdapter.notifyDataSetChanged()
                }

                override fun onCancelled(error: DatabaseError) {
                    showError(error.message)
                }
            })

        // Hashtags
        database.child("posts")
            .addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    snapshot.children.forEach { postSnap ->
                        val hashtags = postSnap.child("hashtags").value
                        val id = postSnap.key ?: ""
                        if (hashtags is List<*>) {
                            hashtags.forEach { tag ->
                                if (tag.toString().contains(query, ignoreCase = true)) {
                                    searchResults.add(SearchItem("Hashtag", tag.toString(), id))
                                }
                            }
                        }
                    }
                    searchAdapter.notifyDataSetChanged()
                    progressBar.visibility = View.GONE
                }

                override fun onCancelled(error: DatabaseError) {
                    showError(error.message)
                }
            })
    }

    private fun showError(message: String) {
        Toast.makeText(requireContext(), "Error: $message", Toast.LENGTH_SHORT).show()
        progressBar.visibility = View.GONE
    }
}
