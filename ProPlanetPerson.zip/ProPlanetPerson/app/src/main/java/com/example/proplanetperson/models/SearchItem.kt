package com.example.proplanetperson.models

data class SearchItem(
    val type: String,
    val text: String,
    val id: String // Add id parameter
)
