package com.example.proplanetperson.models

data class Quote(
    val text: String?,
    val author: String?
)
