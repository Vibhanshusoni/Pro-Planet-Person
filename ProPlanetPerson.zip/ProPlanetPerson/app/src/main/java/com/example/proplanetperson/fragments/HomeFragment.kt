package com.example.proplanetperson.fragments

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import coil.load
import com.example.proplanetperson.CommentActivity
import com.example.proplanetperson.R
import com.example.proplanetperson.adapters.PostAdapter
import com.example.proplanetperson.api.RetrofitInstance
import com.example.proplanetperson.models.Post
import com.example.proplanetperson.models.Quote
import com.google.firebase.database.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class HomeFragment : Fragment() {

    private lateinit var quoteText: TextView
    private lateinit var quoteAuthor: TextView
    private lateinit var swipeRefreshLayout: SwipeRefreshLayout
    private lateinit var natureImage: ImageView
    private lateinit var postRecyclerView: RecyclerView

    private lateinit var postAdapter: PostAdapter
    private val postList = mutableListOf<Post>()
    private lateinit var databaseRef: DatabaseReference

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val view = inflater.inflate(R.layout.fragment_home, container, false)

        // Initialize UI components
        quoteText = view.findViewById(R.id.quoteText)
        quoteAuthor = view.findViewById(R.id.quoteAuthor)
        natureImage = view.findViewById(R.id.natureImage)
        swipeRefreshLayout = view.findViewById(R.id.swipeRefresh)
        postRecyclerView = view.findViewById(R.id.recycler_posts)

        // Setup RecyclerView with onCommentClick handler
        postAdapter = PostAdapter(requireContext(), postList) { post ->
            val intent = Intent(requireContext(), CommentActivity::class.java)
            intent.putExtra("postUrl", post.url)
            intent.putExtra("caption", post.caption)
            startActivity(intent)
        }
        postRecyclerView.layoutManager = LinearLayoutManager(requireContext())
        postRecyclerView.adapter = postAdapter

        // Firebase reference
        databaseRef = FirebaseDatabase.getInstance().getReference("posts")

        // Initial load
        loadQuote()
        loadPosts()

        // Swipe-to-refresh
        swipeRefreshLayout.setOnRefreshListener {
            loadQuote()
            loadPosts()
        }

        return view
    }

    private fun loadQuote() {
        RetrofitInstance.api.getQuotes().enqueue(object : Callback<List<Quote>> {
            override fun onResponse(call: Call<List<Quote>>, response: Response<List<Quote>>) {
                swipeRefreshLayout.isRefreshing = false
                if (response.isSuccessful) {
                    val quotes = response.body()
                    quotes?.let {
                        val randomQuote = it.random()
                        quoteText.text = "\"${randomQuote.text}\""
                        quoteAuthor.text = "- ${randomQuote.author ?: "Unknown"}"
                    }
                } else {
                    Toast.makeText(requireContext(), "Something went wrong", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onFailure(call: Call<List<Quote>>, t: Throwable) {
                swipeRefreshLayout.isRefreshing = false
                Toast.makeText(requireContext(), "Failed to load quote", Toast.LENGTH_SHORT).show()
            }
        })

        // Load a random image from Unsplash
        natureImage.load("https://source.unsplash.com/600x400/?nature,environment") {
            crossfade(true)
            placeholder(R.drawable.eco_icon)
            error(R.drawable.ic_eco)
        }
    }

    private fun loadPosts() {
        swipeRefreshLayout.isRefreshing = true

        databaseRef.orderByChild("timestamp").addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                postList.clear()
                for (postSnapshot in snapshot.children) {
                    val post = postSnapshot.getValue(Post::class.java)
                    post?.let { postList.add(it) }
                }
                postList.reverse() // Show newest first
                postAdapter.notifyDataSetChanged()
                swipeRefreshLayout.isRefreshing = false
            }

            override fun onCancelled(error: DatabaseError) {
                swipeRefreshLayout.isRefreshing = false
                Toast.makeText(requireContext(), "Failed to load posts", Toast.LENGTH_SHORT).show()
            }
        })
    }
}
