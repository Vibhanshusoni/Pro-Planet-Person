package com.example.proplanetperson.api

import com.example.proplanetperson.models.Quote
import retrofit2.Call
import retrofit2.http.GET

interface QuoteApi {
    @GET("quotes")
    fun getQuotes(): Call<List<Quote>>

}
