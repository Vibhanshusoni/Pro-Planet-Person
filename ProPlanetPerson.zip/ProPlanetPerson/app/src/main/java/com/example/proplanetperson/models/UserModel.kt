package com.example.proplanetperson.models

data class UserModel(
    val username: String = "",
    val bio: String = "",
    val profileImageUrl: String = ""
)
