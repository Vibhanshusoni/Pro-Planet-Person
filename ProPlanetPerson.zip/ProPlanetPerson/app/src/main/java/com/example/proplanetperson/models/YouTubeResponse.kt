package com.example.proplanetperson.models

// Data class for the YouTube API response
data class YouTubeResponse(
    val items: List<VideoItem> // A list of VideoItems
)

// Data class for each video item
data class VideoItem(
    val id: VideoId,    // The ID of the video (nested VideoId class)
    val snippet: Snippet // The snippet (video details like title, thumbnails, etc.)
)

// Data class for the VideoId
data class VideoId(
    val videoId: String // Video ID for each video
)

// Data class for the Snippet (metadata like title and thumbnails)
data class Snippet(
    val title: String,    // Title of the video
    val thumbnails: Thumbnails // Thumbnails object containing different resolutions
)

// Data class for the Thumbnails (with different sizes like medium and high)
data class Thumbnails(
    val medium: ThumbnailInfo,  // Medium thumbnail info
    val high: ThumbnailInfo    // High thumbnail info
)

// Data class for the Thumbnail information (URL)
data class ThumbnailInfo(
    val url: String // URL of the thumbnail image
)
