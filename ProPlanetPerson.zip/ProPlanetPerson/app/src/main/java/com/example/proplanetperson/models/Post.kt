package com.example.proplanetperson.models
data class Post(
    val postId: String = "",
    val url: String = "",
    val caption: String = "",
    val timestamp: Long = 0L,
    val userId: String = "",
    var likes: Map<String, Boolean>? = null
) {
    fun getLikeCount(): Int = likes?.size ?: 0
    fun isLikedBy(uid: String): Boolean = likes?.containsKey(uid) == true
}
