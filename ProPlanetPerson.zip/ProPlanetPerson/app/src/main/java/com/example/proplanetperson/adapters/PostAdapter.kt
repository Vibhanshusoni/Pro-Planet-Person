package com.example.proplanetperson.adapters

import android.animation.Animator
import android.content.Context
import android.content.Intent
import android.os.SystemClock
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.airbnb.lottie.LottieAnimationView
import com.bumptech.glide.Glide
import com.example.proplanetperson.R
import com.example.proplanetperson.models.Post
import com.example.proplanetperson.ui.UserProfileActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*

class PostAdapter(
    private val context: Context,
    private val postList: List<Post>,
    private val onCommentClick: ((Post) -> Unit)? = null
) : RecyclerView.Adapter<PostAdapter.PostViewHolder>() {

    private val auth = FirebaseAuth.getInstance()
    private val database = FirebaseDatabase.getInstance().reference

    inner class PostViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val imagePost: ImageView = itemView.findViewById(R.id.imagePost)
        val tvCaption: TextView = itemView.findViewById(R.id.tvCaption)
        val btnComment: View = itemView.findViewById(R.id.btnComment)
        val btnShare: View = itemView.findViewById(R.id.btnShare)
        val likeAnimation: LottieAnimationView = itemView.findViewById(R.id.likeAnimation)
        val likeCountText: TextView = itemView.findViewById(R.id.likeCountText) // Add this in XML
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PostViewHolder {
        val itemView = LayoutInflater.from(context).inflate(R.layout.item_post, parent, false)
        return PostViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: PostViewHolder, position: Int) {
        val post = postList[position]
        val postRef = database.child("posts").child(post.postId).child("likes")
        val currentUserId = auth.currentUser?.uid ?: ""

        // Load image
        Glide.with(context)
            .load(post.url)
            .placeholder(R.drawable.ic_profile_placeholder)
            .error(R.drawable.ic_profile_placeholder)
            .into(holder.imagePost)

        // Caption
        holder.tvCaption.text = post.caption
        holder.tvCaption.visibility = if (post.caption.isNotEmpty()) View.VISIBLE else View.GONE

        // Real-time like count listener
        postRef.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val likes = snapshot.children.mapNotNull { it.key }.toSet()
                holder.likeCountText.text = "${likes.size} likes"
                val isLiked = currentUserId in likes
                holder.likeAnimation.progress = if (isLiked) 1f else 0f
            }

            override fun onCancelled(error: DatabaseError) {
                Log.e("PostAdapter", "Error loading likes", error.toException())
            }
        })

        // Like handling
        var lastClickTime = 0L
        val toggleLike = {
            postRef.get().addOnSuccessListener {
                val isLiked = it.hasChild(currentUserId)
                if (isLiked) {
                    postRef.child(currentUserId).removeValue()
                } else {
                    postRef.child(currentUserId).setValue(true)
                    holder.likeAnimation.playAnimation()
                }
            }
        }

        // Double-tap like
        holder.imagePost.setOnClickListener {
            val clickTime = SystemClock.elapsedRealtime()
            if (clickTime - lastClickTime < 300) {
                toggleLike()
                holder.likeAnimation.visibility = View.VISIBLE
                holder.likeAnimation.playAnimation()
                holder.likeAnimation.addAnimatorListener(object : Animator.AnimatorListener {
                    override fun onAnimationEnd(animation: Animator) {
                        holder.likeAnimation.visibility = View.GONE
                    }

                    override fun onAnimationStart(animation: Animator) {}
                    override fun onAnimationCancel(animation: Animator) {}
                    override fun onAnimationRepeat(animation: Animator) {}
                })
            }
            lastClickTime = clickTime
        }

        // Like tap (heart icon)
        holder.likeAnimation.setOnClickListener {
            toggleLike()
        }

        // Comment click
        holder.btnComment.setOnClickListener {
            onCommentClick?.invoke(post)
        }

        // Share post
        holder.btnShare.setOnClickListener {
            val shareText = buildString {
                append("🌱 Check out this post:\n\n")
                append(post.caption)
                if (post.url.isNotEmpty()) append("\n${post.url}")
            }

            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_SUBJECT, "Eco-Friendly Post from Pro Planet Person")
                putExtra(Intent.EXTRA_TEXT, shareText)
            }

            try {
                context.startActivity(Intent.createChooser(shareIntent, "Share via"))
            } catch (e: Exception) {
                Toast.makeText(context, "Unable to share post", Toast.LENGTH_SHORT).show()
                Log.e("PostAdapter", "Share failed", e)
            }
        }

        // Long press to view user profile
        holder.imagePost.setOnLongClickListener {
            val intent = Intent(context, UserProfileActivity::class.java).apply {
                putExtra("USER_ID", post.userId)
            }
            context.startActivity(intent)
            true
        }
    }

    override fun getItemCount(): Int = postList.size
}
